# Lab -3
#### Grupp: Annie, Emma, Jonathan

## Kalender
### Fungerande kalender
Kalendervyn visar månad för månad och börjar vid dagens år och månad. Den markerar också dagens datum. Det är lätt att byta månad genom att klicka på vardera pil om rubriken med månad och år.

### Att göra-lista
Användaren kan själv lägga till "att göra-punkter"/"to dos" genom att ange datum och fri text. Användaren har en komplett översikt över alla punkter till vänster. I kalendern visas alla punkter i rätt dag samt med en siffra för att hålla koll på hur många punkter det finns för den dagen.

### Dagens tid och datum
Uppe ligger ett block som visar både dagens (rörliga) tid och datum.

#### Repo
https://github.com/AVLarsson/Lab-3

#### Demo
https://avlarsson.github.io/Lab-3/
